package com.example.myapplication;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
Button btnSendSMS, btnOpenMap;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        btnSendSMS = findViewById(R.id.btnSendSMS);
       btnSendSMS.setOnClickListener(this);

                btnOpenMap = (Button) findViewById(R.id.btnOpenMap);
        btnOpenMap.setOnClickListener(this);

       {

           /*
            @Override
            public void onClick(View view){
           {   switch(onCreateView().getId())}
                case R.id.btnOpenMap:
                Intent intent1 = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:59.93188031597721, 30.34947014756851"));
                startActivity(intent1);
                break;
                startActivity(new Intent(getApplicationContext(), Activity_SendSMSPage.class));
            }
        });


            */


       }
    }





    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.activity2_menu, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        switch (item.getItemId()){
            case R.id.menuItem1:
                Toast.makeText(this, "Register menu item is clicked!", Toast.LENGTH_SHORT).show();
                Intent intent = new Intent(getApplicationContext(), MainActivity2_Register.class);
                startActivity(intent);
                return true;
            case R.id.menuItem2:
                Toast.makeText(this, "View List menu item is clicked!", Toast.LENGTH_SHORT).show();
                return true;


        }
        return super.onOptionsItemSelected(item);
    }


    @Override
    public void onClick(View view) {
        switch(view.getId()){
            case R.id.btnOpenMap:
                Intent intent1 = new Intent(Intent.ACTION_VIEW, Uri.parse("geo:59.93188031597721, 30.34947014756851"));
                startActivity(intent1);

                break;
        }
    }
}